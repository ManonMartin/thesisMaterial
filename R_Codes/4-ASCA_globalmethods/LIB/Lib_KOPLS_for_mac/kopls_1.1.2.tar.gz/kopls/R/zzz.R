  .First.lib <-function (lib, pkg)   {
     library.dynam("kopls",package=pkg,lib.loc=lib )
  }
