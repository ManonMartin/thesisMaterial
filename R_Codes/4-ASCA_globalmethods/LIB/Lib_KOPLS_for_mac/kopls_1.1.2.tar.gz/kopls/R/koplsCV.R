###########################################################################
#
# Function for performing K-OPLS cross-validation for a set of
# Y-orthogonal components.
#
# K = Kernel matrix (see 'koplsKernel()' for details)
# Y = Y matrix/vector (predictors), rows are observations, columns are
#           features
# A = number predictive components (integer)
# oax = number of Y-orthogonal components (integer)
#
# nrcv= number of cross-validation rounds (integer)
# cvType = 'nfold' for n-fold, 'mccv' for monte-carlo, 'mccvb' for 
#   monte-carlo class-balanced
# preProcK = 'mc' for meancentering, 'no' for no centering
# preProcY = 'mc' for mean-centering, 'uv' for mc + scaling to unit 
#   variance, 'pareto' for mc + Pareto, 'no' for no scaling
# cvFrac = fraction of samples used for modelling (if cvType is 'mc' or 
#   'mb' - otherwise not used
# modelType = 'da' for discriminant analysis, 're' for regression - if 'da'
#   sensitivity and specificity will be calculated.
#
# Reference: 
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsCV<-function(K,Y,A,oax,nrcv=7,cvType='nfold',preProcK='mc',preProcY='mc',cvFrac=0.75,modelType='re', verbose=TRUE){

release<-'';

#X<-as.data.frame(X);
#Y<-as.data.frame(Y);

N<-nrow(Y);
m<-ncol(Y);
modelMain<-list();

# some minor checks....
if( (as.logical((match(modelType,'da',nomatch=0)))+(as.logical((match(modelType,'daAUC',nomatch=0)))))>0){    
	drRule<-'max'; #move to arg... #this is a parameter for DA decision rule
    
	tmp<-unique(as.vector(unlist(Y)));


	
	if(length(tmp)==2){
	  if(all(tmp==0|tmp==1)){
	    if(m==1){
	      Y<-koplsDummy(Y);
	    }
		classVect<-koplsReDummy(Y);
	  }
	}
	else{
	  if(all(Y%%1==0 && m==1)){
	    classVect<-Y;
	    Y<-koplsDummy(Y+1);
	  }
	}
	 
	nclasses<-length(unique(classVect));
 }

if(as.logical(match(cvType,'mccvb',nomatch=0)) && !as.logical(match(modelType,'da',nomatch=0))){
    stop('Class balanced monte-carlo cross validation only applicable to da modelling');;
  }

if(!any(c(as.logical(match(cvType,'mccvb',nomatch=0))) , as.logical(match(cvType,'mccv',nomatch=0)) , as.logical(match(cvType,'nfold',nomatch=0)))){
    stop(paste(cvType, '- unknown Cross-validation type'));
  }

YcenterType<-"no";
YscaleType<-"no";
if (preProcY!="no") {
    YcenterType<-"mc";
    if (preProcY!="mc") {
        YscaleType<-preProcY;
    }
}
  
oay<-0;#tmp fix kopls
Yhat<-NULL;#matrix(NaN,nrow=N,ncol=m);
YhatDaSave<-array(list(),c(oax+1,oay+1));#list(NULL);


pressyVars<-array(list(),c(oax+1,oay+1));#list(NULL):#cell(1,1);
pressyVarsTot<-array(list(),c(oax+1,oay+1));#list(NULL);#cell(1,1);
pressy<-matrix(NaN,oax+1,oay+1);
pressyTot<-matrix(NaN,oax+1,oay+1);
cvTestIndex<-NULL;
cvTrainingIndex<-NULL;

for( icv in 1:nrcv){
  if (verbose)
  {
  	print(paste('Cross validation round: ',icv,'...'));
  }

  #set up cv
  cvSet<-koplsCrossValSet(K,Y,cvType,nrcv,icv,cvFrac);
  cvTestIndex<-c(cvTestIndex,cvSet$testInd);
  cvTrainingIndex<-c(cvTrainingIndex,cvSet$trainInd);
  
  #get kernel matrics
  KtrTr<-cvSet$KTrTr
  KteTe<-cvSet$KTeTe
  KteTr<-cvSet$KTeTr

 
  # center Y and K matrices
  YScaleObj<-koplsScale(cvSet$yTraining,center=YcenterType,scale=YscaleType);
  YScaleObjTest<-koplsScaleApply(YScaleObj,cvSet$yTest);
  if (preProcK=="mc") {
	KteTe<-koplsCenterKTeTe(KteTe,KteTr,KtrTr);
	KteTr<-koplsCenterKTeTr(KteTr,KtrTr);
	KtrTr<-koplsCenterKTrTr(KtrTr);
  }
  

  model<-koplsModel(KtrTr,YScaleObj$x,A,oax,'none','none');

    #ssy<-sum((cvSet$yTest)^2);
    #ssyVars<-colSums((cvSet$yTest)^2);	
    #ssx<-sum(diag(KteTe));
    ssy<-sum((YScaleObjTest$x)^2);
    ssyVars<-colSums((YScaleObjTest$x)^2);	
    ssx<-sum(diag(KteTe));


    if(icv==1){
      ssyTot<-ssy;
      ssyVarsTot<-ssyVars;
      ssxTot<-ssx;

    }
    else{
      ssyTot<-ssyTot+ssy;
      ssyVarsTot<-ssyVarsTot+ssyVars;        
      ssxTot<-ssxTot+ssx;
      }
    
    
  for( ioax in 1:(oax+1)){
    for( ioay in 1:1){#(oay+1)){
       
       #yhat  ====HERE : change inteface on the scaling of cvset?
    
    
      modelPredy<-koplsPredict(KteTr, KteTe,KtrTr, model,ioax-1,rescale=FALSE);	                                   

    
      #pressy[ioax, ioay]<-sum((cvSet$yTest-modelPredy$Yhat)^2);
      #pressyVars[ioax, ioay]<-list(colSums((cvSet$yTest-modelPredy$Yhat)^2));
      pressy[ioax, ioay]<-sum((YScaleObjTest$x-modelPredy$Yhat)^2);
      pressyVars[ioax, ioay]<-list(colSums((YScaleObjTest$x-modelPredy$Yhat)^2));
             
            
            if((icv==1)){
                pressyTot[ioax,ioay]<-pressy[ioax,ioay];
                pressyVarsTot[ioax,ioay]<-pressyVars[ioax,ioay];
            }
            else{
                pressyTot[ioax,ioay]<-pressyTot[ioax,ioay]+pressy[ioax,ioay];
                pressyVarsTot[ioax,ioay]<-list(pressyVarsTot[ioax,ioay][[1]]+pressyVars[ioax,ioay][[1]]);
              }
              
            #browser()
			
			
            #if 'da' save Yhat for all rounds
if( (as.logical((match(modelType,'da',nomatch=0)))+(as.logical((match(modelType,'daAUC',nomatch=0)))))>0){    
                    #if(icv==1){
                    #    YhatDaSave{ioax,ioay}<-[];                        
                    #}

                    #might not be right...
                    tmp<-koplsRescale(YScaleObj,modelPredy$Yhat);
                    YhatDaSave[ioax,ioay]<-list(rbind(YhatDaSave[ioax,ioay][[1]],tmp));                               
                  }

    
            #if highest number of oscs - save Yhat and Xhat
            if(ioax==oax+1){# && ioay==oay+1){                
                    #if(icv==1){
                    #    Yhat<-[];
                    #    Xhat<-[];
                    #}                    
 
              tmp<-koplsRescale(YScaleObj,modelPredy$Yhat);

                    Yhat<-rbind(Yhat,tmp);
  
            

                  }
            
  }
}
  
}
   #end icv

modelMain$cv$Yhat<-Yhat;


#YScaleObj<-koplsScale(Y,center=YcenterType,scale=YscaleType);
#KtrTr<-K
#if (preProcK=="mc") {
#	KtrTr<-koplsCenterKTrTr(KtrTr);
#}
#modelMain$koplsModel<-koplsModel(KtrTr,YScaleObj$x,A,oax,preProcK,preProcY);

KtrTr<-K
modelMain$koplsModel<-koplsModel(KtrTr,Y,A,oax,preProcK,preProcY);
modelMain$cv$Tcv<-Yhat%*%modelMain$koplsModel$Cp%*%modelMain$koplsModel$Bt[[oax+1]];


    modelMain$cv$Q2Yhat<-NULL;
    modelMain$cv$Q2YhatVars<-array(list(),c(oax+1,oay+1));#cell(1,1);

    for( ioax in 1:(oax+1)){
        for( ioay in 1:(oay+1)){
            modelMain$cv$Q2Yhat[ioax,ioay]<-1-pressyTot[ioax,ioay]/ssyTot;          
            modelMain$cv$Q2YhatVars[ioax,ioay]<-list(1-pressyVarsTot[ioax,ioay][[1]]/ssyVarsTot);

}
}

    modelMain$cv$cvTestIndex<-cvTestIndex;
    modelMain$cv$cvTrainingIndex<-cvTrainingIndex;

if(as.logical(match(modelType,'da',nomatch=0))){


sensSpecRes<-list(1);
da<-list(1);
        #get sens/spec for each y-orth component... eval of model
  for( i in 1:(oax+1)){ #we would have no osc comps for dummy matrix...
    if(as.logical(match(drRule,'max',nomatch=0)) ){
      predClass<-koplsMaxClassify(YhatDaSave[i,1][[1]]);
    }
                else{
                  if( as.logical(match(drRule,'fixed',nomatch=0))    ){
                    predClass<-koplsBasicClassify(YhatDaSave[i,1][[1]],1/nclasses);
                  }
                  else{
                    stop(paste('Decision rule given: ',drRule,'is not valid/implemented'))
                  }
                }
da$sensSpec[[i]]<-koplsSensSpec(classVect[cvTestIndex], predClass);  
if (((dim(YhatDaSave[[ioax,ioay]])[2]<3))+(length(unique(classVect[cvTestIndex]))==2)==2){
da$ROC[[i]]<-koplsRoc(YhatDaSave[[ioax,ioay]],classVect[cvTestIndex])	
}
  }


  
           da$confusionMatrix<-koplsConfusionMatrix(classVect[cvTestIndex], predClass);
           da$trueClass<-classVect[cvTestIndex];
            da$nclasses<-nclasses;
        modelMain$da<-da;
        modelMain$da$predClass<-predClass;        
        modelMain$da$decisionRule<-drRule;
                #CHANGE TO ORIGNAL ORDER IF NFOLD CV - for backward
                #compatibility and comparison w/ simca-p etc
        if(as.logical(match(cvType,'nfold',nomatch=0))){
            tmp<-sort(cvTestIndex,index.return=TRUE);
            cvOrder<-tmp$ix;
            modelMain$da$predClass<-modelMain$da$predClass[cvOrder];
            modelMain$da$trueClass<-modelMain$da$trueClass[cvOrder];           
        }
        
}#end if da


    #CHANGE TO ORIGNAL ORDER IF NFOLD CV - for backward
    #compatibility and comparison w/ simca-p etc
    if(as.logical(match(cvType,'nfold',nomatch=0))){
        
        tmp<-sort(cvTestIndex,index.return=TRUE);
        cvOrder<-tmp$ix;
        modelMain$cv$Yhat<-modelMain$cv$Yhat[cvOrder,];
        modelMain$cv$Tcv<-modelMain$cv$Tcv[cvOrder,];

}
    
modelMain$release<-release;
#close(h);        
modelMain$args$oax<-oax;
modelMain$args$A<-A;

class(modelMain)<-"koplscv"

return(modelMain);

}






