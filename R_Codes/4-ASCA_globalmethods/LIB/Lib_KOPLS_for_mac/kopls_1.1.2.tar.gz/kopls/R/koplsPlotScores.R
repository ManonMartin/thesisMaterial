###########################################################################
#
# Plots scores for a K-OPLS model.
#
# If only the model is specified, all possible combinations of
# score vectors will be displayed as a scatter plot matrix.
#
# Otherwise, a scatter plot is displayed with the following settings:
# x = the vector number for the x axis
# xsub = the vector identifier {'p', 'o'} for the x axis
# y = the vector number for the y axis
# ysub = the vector identifier {'p', 'o'} for the y axis
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsPlotScores<-function(model, x=NA, xsub="p", y=NA, ysub="o", ...) {

	if (class(model) != "kopls") {
		stop(paste("Unknown model type: '", class(model), "' (must be of type 'kopls'). Aborting.", sep=""))
	}
	

	## The default visualization is a scatter plot matrix
	## of small multiples.
	## Diagonal depicts the density of a variable.
	if (is.na(x) | is.na(y)) {

		Tall<-model$T
		labels<-paste("tp", 1:model$A, sep=",")
			
		if (model$nox > 0) {
			Tall<-cbind(Tall, model$To)
			labels<-c(labels, paste("to", 1:model$nox, sep=","))
		} else {
			tos<-NULL
		}

		

		layout.mat<-matrix(nrow=ncol(Tall), ncol=ncol(Tall), data=1:(ncol(Tall)^2), byrow=TRUE)
		#curr.margin<-par("mai")
		#par(mai=c(0.6, 0.5, 0.1, 0.1))
		layout(layout.mat)
		for (i in 1:ncol(Tall)) {
			for (j in 1:ncol(Tall)) {
			
				## Multiple arguments not supported here
				if (i == j) {
					plot(density(Tall[, i]), main="", ylab="Density", xlab=labels[i])
				} else {	
					plot(x=Tall[, i], y=Tall[, j], xlab=labels[i], ylab=labels[j], ...)
				}
			
			}
		}
		layout(1) #reset
		
	} else
	{
		if ( (xsub=="p" & x > model$A) | (xsub=="o" & x > model$nox) )
			stop("X variable outside range of model. Aborting.")
		
		if ( (ysub=="p" & y > model$A) | (ysub=="o" & y > model$nox) )
			stop("Y variable outside range of model. Aborting.")
		
		
		if (xsub=="p") {
			xvec<-model$T[,x]
		} else if (xsub=="o") {
			xvec<-model$To[,x]
		} else 	{
			stop(paste("Unknown model component specification for x : ", xsub, "; should be {o, p}. Aborting.", sep=""))
		}
		
		if (ysub=="p") {
			yvec<-model$T[,y]
		} else if (ysub=="o") {
			yvec<-model$To[,y]
		} else 	{
			stop(paste("Unknown model component specification for y : ", ysub, "; should be {o, p}. Aborting.", sep=""))
		}
		
		#browser()
		
		plot(x=xvec, y=yvec, xlab=paste("t", xsub, ",", x), ylab=paste("t", ysub, ",", y), ...)
	}

}


