###########################################################################
# 
# Classification function that assesses class belonging of 'data'
# based on a threshold 'k'.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsBasicClassify<-function(data,k){

#   k is boundary, data is y_hat
    predClass=matrix(NaN,ncol=ncol(data),nrow=nrow(data));
     for(i in 1:length(data[,1])){        
        tmp<-which(data[i,]>k);
        predClass[i,1:length(tmp)]=tmp;
     }     
	 
	 return(predClass);
}
