###########################################################################
#
# Predictions of Y for a test kernel matrix based on a training model.
#
# * Input:
# KteTr = Xte*Xtr' kernel matrix
# Ktest = Xte*Xte' kernel matrix
# Ktrain = Xtr*Xtr' kernel matrix (same as used in model training)
# model = K-OPLS model object
# nox = number of Y-orthogonal components. If not specified, the number
#	used during model training will be employed.
# rescaleY = Boolean parameter. If true, Yhat is rescaled according to
#	the pre-processing settings of the model. If false, Yhat is not
#	rescaled (default).
#
# * Output:
# Tp = predicted predictive score matrix
# To = predicted Y-orthogonal score matrix
# EEprime = The deflated KteTe matrix, useful e.g for residual stats.
# Yhat = The predicted value of Y
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsPredict<-function(KteTr,Ktest,Ktrain, model,nox=NA,rescaleY=FALSE){

if (class(model) != "kopls") {
	stop(paste("Unknown model type: '", class(model), "' (must be of type 'kopls'). Aborting.", sep=""))
}

## centering (order of these arg is important...)

KteTeMc<-Ktest;
if (model$preProc$K=='mc') {
	KteTeMc<-koplsCenterKTeTe(Ktest,KteTr,Ktrain);
}
KteTe<-matrix(list(),ncol=model$nox+1,nrow=model$nox+1);
#KteTe<-cell(model.nox+1,model.nox+1);
KteTe[1,1][[1]]<-KteTeMc;

KteTrMc<-KteTr;
if (model$preProc$K=='mc') {
	KteTrMc<-koplsCenterKTeTr(KteTr,Ktrain);
}
KteTrTmp<-matrix(list(),ncol=model$nox+1,nrow=model$nox+1);
KteTrTmp[1,1][[1]]<-KteTrMc;
KteTr<-KteTrTmp;


## init of Y-orth scores
to<-list();
Tp<-list();

## check if last arg is number of components to use in prediction:

if(!is.na(nox)){
  #nox already assigned
    if(nox>model$nox){
        warning('Number of Y-orthogonal components to use is higher than in model - setting number of Yorth to max in model');
        nox<-model$nox;
  }
} else {
    nox<-model$nox;
}

## KOPLS prediction

if(nox>0){
for(i in 1:nox){ #step1
    
    #step2

 
    Tp[[i]]<-KteTr[i,1][[1]]%*%model$Up%*%model$Sps;
  

    #Yhat[[i]]<-Tp[[i]]%*%model$Bt[[i]]%*%model$Cp';

    #step3
    to[[i]]<-(KteTr[i,i][[1]]-Tp[[i]]%*%t(model$Tp[[i]]))%*%model$Tp[[i]]%*%model$co[[i]]%*%model$so[[i]]^(-1/2);
    
    #step4
    to[[i]]<-to[[i]]/model$toNorm[[i]];

    # step 4$5 deflate KteTe. (this is an EXTRA feature - not in alg. in
    # paper )
    KteTe[i+1,i+1][[1]] <- KteTe[i,i][[1]] - KteTr[i,i][[1]]%*%model$to[[i]]%*%t(to[[i]]) - to[[i]]%*%t(model$to[[i]])%*% t(KteTr[i,i][[1]]) + to[[i]]%*%t(model$to[[i]])%*%model$K[i,i][[1]]%*%model$to[[i]]%*%t(to[[i]]);
    
    #step5
    KteTr[i+1,1][[1]]<-KteTr[i,1][[1]] -to[[i]]%*% t(model$to[[i]]) %*% t(model$K[1,i][[1]]);
    
    #step6
    KteTr[i+1,i+1][[1]]<-KteTr[i,i][[1]]-KteTr[i,i][[1]]%*% model$to[[i]]%*% t(model$to[[i]])-to[[i]]%*%t(model$to[[i]])%*%model$K[i,i][[1]]+to[[i]]%*%t(model$to[[i]])%*%model$K[i,i][[1]]%*%model$to[[i]]%*%t(model$to[[i]]);

}  #end for   #step7
}#end if nox

 if(nox==0){
     i<-0;
   }


Tp[[i+1]]<-KteTr[i+1,1][[1]]%*%model$Up%*%model$Sps;
#Yhat[[i+1]]<-Tp[[i+1]]%*%model$Bt[[i+1]]%*%t(model$Cp);
Yhat<-Tp[[i+1]]%*%model$Bt[[i+1]]%*%t(model$Cp);

if (rescaleY) {
	if (model$preProc$Y!='no' & model$preProc$Y!='none' ) {
		Yhat<-koplsRescale(model$preProc$paramsY, Yhat)
	} else {
		warning("Attempted re-scale of Yhat although no pre-processing parameters have been set.")
	}
}


#---- Extra stuff ----------------------------------
#this appears to be correct - but does not match previous code...
EEprime<-(KteTe[i+1,i+1][[1]]-Tp[[i+1]]%*%t(Tp[[i+1]])); 
#--------------------------------------------------
modelp<-list();
modelp$Tp<-Tp;
modelp$T<-Tp[[nox+1]];
modelp$to<-to;
#modelp$KteTr<-KteTr;
modelp$EEprime<-EEprime;
modelp$Yhat<-Yhat;
return(modelp);
 }
