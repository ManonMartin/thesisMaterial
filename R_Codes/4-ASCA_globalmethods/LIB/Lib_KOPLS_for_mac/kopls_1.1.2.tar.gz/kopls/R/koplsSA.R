###########################################################################
#
# Simulated annealing - This function will only work for the optimisation of
# one parameter! The error is mimimised, i.e. (1-Q2) mimimisation is the
# target function. Make sure the correct dataset is loaded with Xtr as X
# training set and Ytr for the Y training set.
#
# Output:
# settings  = Settings and outcomes for simulated annealing, including Optset = 
#             Optimal settings 
# 
# Required input parameters:
# Xtr       = Training X data.
# Ytr       = Training Y data.
# A         = The number of Y-predictive components (integer).
# oax       = The number of Y-orthogonal components (integer).
# modelType = 'da' for discriminant analysis, 're' for regression.
#             If 'da', the mean sensitivity is optimised, for 'daAUC' the area
#             under the receiver operating characteristic curve is optimised 
#             (only for two-class problems). 
#
# Possible Input parameters for Simulated Annealing, pair-wise input in optargin:
# kernelType= 'g' for Gaussian (default).
# preProcK  = Scaling of X data, 'none' or default 'mc'.
# preProcY  = Scaling of Y data; 'mc' for mean-centering (default), 'uv' for mc 
#             + scaling to unit variance, 'pareto' for mc + Pareto, 'none' for 
#             no scaling.
# stX       = Starting position for algorithm search - can be initiated
#             automatically or from a number of preset positions. 
# t0        = Starting temperature; default = 0.1.
# epsilon   = Termination criterion, default = 0.01.
# neps      = Number of subsequent optimised points evaluated for convergence
#             criterion, default = 2.
# v_0       = Starting step vector size, will be adjusted throughout 
#             optimisation but should preferable be able to cover a large range 
#             of the possible optimal kernel parameter values; default is stX.
# ns        = Number of points before reducing vector length, default 5.
# nt        = Number of vector reductions before temperature update, default 5.
# rt        = Exponential cooling of temperature, default = 0.1, should be 
#             between 0 and 1.
# nrreps    = Number of runs, default = 1.
# verbose   = TRUE for plotting and displaying temperature updates and results, 
#             FALSE for not (default).
#
# PLS model parameters
# nrcvinner = Number of cross-validation rounds (integer), default 10.
# cvType    = Type of cross-validation. Either 'nfold' for n-fold
#             cross-validation, 'mccv' for Monte Carlo CV or 'mccvb' for Monte 
#             Carlo class-balanced CV; default 'mccv' for 're' and 'mccvb' for 
#             'da' and 'daAUC' modelType. See also 'koplsCrossValSet()'.
# cvFrac    = Fraction of observations in the trainingset during
#             crossvalidation. Only applicable to 'mccv', 'mccvb'
#             crossvalidation (see 'cvType'),default 0.75.
#
#Reference: Corona et al; 'minimizing multimodal functions of continuous
#variables with the "simulated annealing" algorithm', ACM transactions on
#Mathematical Software, vol. 13, no.3, september 1987, pages 262-280.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsSA<-function(Xtr,Ytr,A,oax,modelType,kernelType='g',nrcvinner=10,cvType=NULL,cvFrac=0.75,stX=NULL,preProcK='mc',preProcY='mc',nrreps=1,t0=0.1,epsilon=0.01,neps=2,v0=NULL,ns=5,nt=5,rt=0.1,verbose=FALSE){ 

### Basic checks and default settings
  if (!((preProcK=='mc')|(preProcK=='none'))){
   warning('this is an incorrect setting for X scaling')
  }

  if (!((preProcY=='uv')|(preProcY=='mc')|(preProcY=='none')|(preProcY=='pareto'))){
   warning('this is an incorrect setting for Y scaling')
  } 

  if (!((kernelType=='g'))){
   warning('this is an incorrect setting for kernelType')
  } 

  if (is.null(stX)){
    if (kernelType=='g'){
      stX<-runif(1) 
    } else {
       warning('your kerneltype is incorrect, cannot determine best starting value')
    }
   }

  if(!(length(stX)==nrreps)){
   warning(paste('start values should have as many entries as number of repititions: ', as.character(nrreps)))} else
  {if (min(stX)<=0) {
    warning('start value should be bigger than zero')}
  }

  if (is.null(v0)){    
   v0<-stX
  }
  
  if (is.null(cvType)){    
   if ((modelType=='daAUC')| (modelType=='da')){
     cvType<-'mccvb'
   } else {
     if (modelType=='re'){
       cvType<-'mccv'
     }
   }
  }

  stopifnot(rt>0 &rt<1)

  if (!((modelType=='daAUC')|(modelType=='da')|(modelType=='re'))){
    warning('this is not a valid modelType') 
  }

  if (is.null(Xtr)){
   warning('this is not a valid X data matrix')
  }

  if (is.null(Ytr)){
   warning('this is not a valid Y data matrix')
  }

  if (is.null(A)){
   warning('this is not a correct setting for the number of Y-predictive components (integer).')
  }

  if (is.null(oax)){
   warning('this is not a correct setting for the number of Y-orthogonal components (integer).')
  }
  if (!(verbose==TRUE|verbose==FALSE)){
   warning('this it not a correct setting for verbose: should be TRUE or FALSE.')
  }

### Start of the iterations
settings<-list()

  for (reps in 1:nrreps){
### Step 0: Initialisation
    ptm <- proc.time()          
    f0<- koplsModelInternal(Xtr=Xtr,Ytr=Ytr,A=A,oax=oax,nrcv=nrcvinner,cvType=cvType,preProcK=preProcK,preProcY=preProcY,cvFrac=cvFrac,modelType=modelType,kernelType=kernelType,kParamNew=stX[nrreps]) 
    fold<- f0
    xold<- stX[nrreps]
    vnew<- v0
    n1<- 0             
    tnew<- t0
    c1<- 2              
    maxits<- 1000        # maximum number of iterations to prevent long calculation times.
    xlist<- xold         # list of all evaluated Xs
    flist<- fold         # list of all evaluated fs
    tlist<- tnew         # list of all evaluated temperatures
    xopt<- xold
    fopt<- fold
    xoptlist<- xopt      # list of increasingly better Xs
    foptlist<- fopt      # list of increasingly better fs
    xshortlist<- xopt    # list of Xs after each temperature change
    fshortlist<- fopt    # list of fs after each temperature change
    vlist<- vnew         # list of step vectors
    tshortlist<- tnew    # list of Temperatures.

### Step 1: Calculate new X
    teli<- 1                                      
    telk<- 1                                           

    while (!((length(fshortlist)>neps) && (min(fshortlist[(length(fshortlist)-neps):(length(fshortlist)-1)]-fshortlist[length(fshortlist)]<=epsilon) & (fshortlist[length(fshortlist)]-fopt)<=epsilon))){ 
      telm<- 1                                        
      while (telm<= nt) {                              # time to reduce the temperature otherwise
        telj<- 1; 
        while (telj<= ns) {                            
          xnew<- xold+runif(1,min=-1,max=1)*vnew       # starting from point xold, generate a random point Xnew
          while (xnew<=0) {                            # if new point is negative
            xnew<- xold+runif(1,min=-1,max=1)*vnew     # test if new X value is positive
          }



 ### Step 2: Evaluate value in new X, accept or reject this as new starting point
          fnew<- koplsModelInternal(Xtr=Xtr,Ytr=Ytr,A=A,oax=oax,nrcv=nrcvinner,cvType=cvType,preProcK=preProcK,preProcY=preProcY,cvFrac=cvFrac,modelType=modelType,kernelType=kernelType,kParamNew=xnew); 
          if (fnew <=fold) {                           
            xold=xnew
            fold=fnew
            xlist<- c(xlist,xold)
            flist<- c(flist,fold)
            tlist<- c(tlist,tnew)
            teli<- teli+1
            n1=n1+1                                    # used to determine how to update step vector; number of accepted moves  
            if (fold<fopt) {                           # if the new value is smaller than overall minimum
              xopt<- xold                              
              fopt<- fold
              xoptlist<- c(xoptlist,xopt) 
              foptlist<- c(foptlist,fopt)
            } 
          } else {                                     # if not improved, accept or reject slightly worse point with probability from Metropolis move
            compnr<- runif(1,min=0,max=1)
            if (compnr<exp((fold-fnew)/tnew)) {        
              xold<- xnew                            
              fold<- fnew
              xlist<- c(xlist,xold)
              flist<- c(flist,fold)
              tlist<- c(tlist,tnew)
              teli<- teli+1
              n1<- n1+1
            }
          }
          telj<- telj+1                              
        }
### Step 3: Change the step vector component, 
        if (n1>(0.6*ns)) {     
          vnew<- vnew*(1+c1*(((n1/ns)-0.6)/0.4)) 
        } else {
	    if (n1 < 0.4*ns) {
            vnew<- vnew/(1+c1*((0.4-(n1/ns))/0.4)) 
          } else {
            vnew<- vnew 
          }
        } 
        vlist<- c(vlist,vnew)                          
        n1<- 0
        telm<- telm+1
      }

### Step 4: Update temperature
      tnew=rt*tnew 
      tshortlist=c(tshortlist,tnew)
      xshortlist=c(xshortlist,xold)                    
      fshortlist=c(fshortlist,fold)
      if (verbose){
        print(paste('Temperature update: ', tnew))
        par(mfcol=c(2,1))
        plot(tshortlist,col='blue',pch='x',main='Temperature',xlab='number of temperature updates',ylab='')
        lines(tshortlist)
        plot(fshortlist,col='red',pch='x', main=expression(paste(plain(1-Q)^2)),xlab='number of temperature updates',ylab='') 
        lines(fshortlist)
      }
      xold<- xopt
      fold<- fopt                        
      telk<- telk+1
      teli<- teli+1


### Step 5: stop after convergence or exceeding maximum number of iterations
      if (teli>maxits) {
        print('stopped before convergence')
        break
      }
    }
    timeans<-(proc.time()-ptm)[3]                                        # this is toc; end of time measurement
    settings$Optset[reps]<- list(xopt[length(xopt)])                     # optimal settings
    settings$time[reps]<- list(timeans)                                  # total time per optimisation
    settings$Q2[reps]<- list(1-fopt[length(fopt)])                       # Q2 or sensitivity if DA per optimisation
    settings$preProcK<- list(preProcK)                                   # scaling of X matrix
    settings$preProcY<- list(preProcY)                                   # scaling of Y matrix
    settings$stX[reps]<- list(stX[reps])                                 # starting value of kernel parameter
    settings$t0<- list(t0)                                               # starting temperature
    settings$epsilon<- list(epsilon)                                     # termination criterion
    settings$neps<- list(neps)                                           # number of subsequent optimised points evaluated for convergence
    settings$v0[reps]<- list(v0)                                         # starting step vector size 
    settings$ns<- list(ns)                                               # number of points before reducing vector length
    settings$nt<- list(nt)                                               # number of vector reductions before temperature update
    settings$rt<- list(rt)                                               # rate of exponential cooling of temperature
    settings$nrreps<- list(nrreps)                                       # number of runs
    settings$nrcvinner<- list(nrcvinner)                                 # number of cross-validations
    settings$cvType<- list(cvType)                                       # type of cross-validation
    settings$cvFrac<- list(cvFrac)                                       # fraction of observations in the trainingset during cross-validation
    settings$modelType<- list(modelType)                                 # PLS model type: regression or discriminant analysis
    settings$Xtr<- list(Xtr)                                             # training X data
    settings$Ytr<- list(Ytr)                                             # training Y data
    settings$A<- list(A)                                                 # number of predictive components
    settings$oax<- list(oax)                                             # number of Y-orthogonal components
    settings$n1<- list(n1)                                               # number of optimisation directions
    settings$c1<- list(c1)                                               # varying criterion for step size update
    settings$kernelType<- list(kernelType)                               # kernel type
    settings$maxits<- list(maxits)                                       # maximum number of iterations
    settings$xlist[reps]<- list(xlist)                                   # list of all evaluated Xs
    settings$flist[reps]<- list(flist)                                   # list of all evaluated fs
    settings$tlist[reps]<- list(tlist)                                   # list of all evaluated temperatures
    settings$xoptlist[reps]<- list(xoptlist)                             # list of increasingly better Xs
    settings$foptlist[reps]<- list(foptlist)                             # list of increasingly better fs
    settings$xshortlist[reps]<- list(xshortlist)                         # list of Xs after each temperature change
    settings$fshortlist[reps]<- list(fshortlist)                         # list of fs after each temperature change
    settings$tshortlist[reps]<- list(tshortlist)                         # list of temperature updates
    settings$vlist[reps]<- list(vlist)                                   # list of step vectors
  }
  return(settings)
}

