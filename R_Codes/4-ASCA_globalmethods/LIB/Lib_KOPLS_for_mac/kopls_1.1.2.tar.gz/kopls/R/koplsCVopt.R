###########################################################################
#
# Function for performing K-OPLS cross-validation for a set of
# Y-orthogonal components. The function returns a number of diagnostic
# parameters which can be used to determine the optimal number
# of model components. 
#
# INPUT:
# X = The measurement matrix.
# Y = The response matrix. Could be binary (for discriminant analysis) or 
#     real-valued.
# A = Number Y-predictive components (integer).
# oax = Number of Y-orthogonal components (integer).
# modelType = 're' for regression, 'da' and 'daAUC' for discriminant analysis,
#   If 'da' or 'daAUC', sensitivity and specificity will be calculated
#   together with the area under the ROC curve. For simulated annealing, 
#   optimisation is done for area under ROC curve in 'daAUC' (only for two-class
#   problems), and for 'da' the mean sensitivity is optimised.

# opt = Optional setting to do kernel parameter optimisation, 'no' for no
#       optimisation, uses kernelParams, or 'SA' for simulated annealing 
#       (default for gaussian kernel), 'GS' for gridsearch between two values as
#       input in kernelParams (default for polynomial kernel).
# nrcvouter = Number of outer cross-validation rounds (integer, default = 20).
# nrcvinner = Number of inner cross-validation rounds (integer, default = 10).
# cvType = Type of cross-validation. Either 'nfold' for n-fold cross-validation,
#  'mccv' for Monte Carlo CV or 'mccvb' for Monte Carlo class-balanced CV; 
#   default 'mccv' for 're' and 'mccvb' for 'da' and 'daAUC' modelType. See also 
#   'koplsCrossValSet()' for details.
# preProcK = Pre-processing settings for the kernel matrix. Either 'mc' for 
#   meancentering (default), 'none' for no pre-processing, default 'mc'.
# preProcY = Pre-processing parameters for Y. Either 'mc' for mean-centering
#   (default), 'uv' for mc + scaling to unit variance, 'pareto' for mc + Pareto-
#   scaling or, 'none' for no scaling, default 'mc'.
# cvFrac = Fraction of observations in the training set during
#          cross-validation. Only applicable for 'mccv' or 'mccvb'
#          cross-validation (see 'cvType'), default 0.75.
# verbose = If FALSE (default), no output will be displayed, if TRUE some
#           output will be displayed regarding the cross-validation progress.
# kernelType = kernel type; 'g' for gaussian (default) and 'p' for polynomial.
# kernelParams = settings for the kernel parameter, leave empty for
#                optimisation with SA, give three values c(start, end, nrsteps]) 
#                for gridsearch, between which the gridsearch will be performed 
#                and the number of steps; note the kernel parameter can not be 
#                zero, and polynomial parameters can only be integer.
# optional settings = used in SA optimisation
#   stX      = Starting position for algorithm search - can be initiated
#              automatically or from a number of preset positions.
#   t0       = Starting temperature; default = 0.1.
#   epsilon  = Termination criterion, default = 0.01.
#   neps     = Number of subsequent optimised points evaluated for convergence
#               criterion, default 2.
#   v0       = Starting step vector size, will be adjusted throughout 
#              optimisation but should preferable be able to cover a large range
#              of the possible optimal kernel parameter values; default is stX.
#   ns       = Number of points before reducing vector length, default 5.
#   nt       = Number of vector reductions before temperature update, default 5.
#   rt       = Exponential cooling of temperature, default 0.1.
#   nrreps   = Number of runs, default 1.
#
# OUTPUT
# modelMain = Object with 'A' predictive components and 'oax'
#             Y-orthogonal components. Contains the following entries:
# koplsModel = Model calculated with all data and using single (i.e. not-nested)
#              cross-validation optimisation of the kernel parameter.
# KParamfinal = Final kernel parameter used, based on the full data set.
# kernelParamslist = (best if optimised) kernel parameter for different
#                    CV rounds.
# cv = Cross-validation results:
#      Q2Yhat = Total Q-square result for all Y-orthogonal components.
#      Q2YhatVars = Q-square result per Y-variable for all Y-orthogonal
#                   components.
#	 Yhat = All predicted Y values as a concatenated matrix.
#	 Tcv = Predictive score vector T for all cross-validation rounds.
#	 cvTrainIndex = Indices for the training set observations during
#                     the cross-validation rounds.
#	 cvTestIndex = Indices for the test set observations during the
#                    cross-validation rounds.
# da = Cross-validation results specifically for discriminant
#      analysis (DA) cases:
#  predClass = Predicted class list per class and Y-orthogonal
#                  components (integer values).
#	 trueClass = Predicted class list per class and Y-orthogonal
#                  components (integer values).
#	 sensSpec = Sensitivity and specificity values per class and
#                 Y-orthogonal components (integer values).
#	 confusionMatrix = Confusion matrix during cross-validation
#                        rounds.
#	 nclasses = Number of classes in model.
#	 decisionRule = Decision rule used: 'max' or 'fixed'.
#  ROC = the AUC (area under ROC curve) and the two vectors based on sensitivity 
#        (sens) and 1-specificity (spec) used for calculation, based on the 
#        training data.
# args = Arguments to the function:
#  	   A = Number of Y-predictive components.
#	   oax = Number of Y-orthogonal components.
#
#Additional SA output:
#  SAsettings = Settings for simulated annealing.
#
#Additional GS output:
#  GSresults = Q2 or sensitivity/specificity for the gridsearched values
#         for the different cross-validation rounds.
#  GSsettings = Grid that was searched.
#
# Reference: 
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsCVopt<-function(X,Y,A,oax,modelType,opt=NULL,nrcvouter=20,nrcvinner=10,cvType=NULL,preProcK='mc',preProcY='mc',cvFrac=0.75, verbose=FALSE,kernelType='g',kernelParams=NULL,...){
# some minor checks....
release<-''
if (is.null(opt)){
  if (kernelType=='g'){
    opt<-'SA'}
  if (kernelType== 'p'){
    opt<-'GS'
    print('you have to enter three settings (start, end, interval) for gridsearch of a polynomial function, if you have not already done so')}
} 
 
if (opt=='SA' & kernelType=='p'){
   stop('use a gridsearch to optimise the polynomial kernel')
  } 
  
if (!(opt=='no')){  
CVptm <- proc.time()}
N<-nrow(Y)
m<-ncol(Y)
modelMain<-list()
kernelParamtemp<-NULL

if (is.null(kernelParams) & opt=='no'){
   simpleError('if you do not want optimisation of the kernel parameter, enter a value for kernelParams')
  } else {
  if (opt=='GS' & length(kernelParams)!=3) {
    warning('for gridsearch, enter two values in between which the kernelParameter setting will be chosen and the stepsize in kernelParams')
  }
}  

if (is.null(cvType)){    
 if ((modelType=='daAUC')| (modelType=='da')){
   cvType<-'mccvb'
 } else {
   if (modelType=='re'){
     cvType<-'mccv'
   }
 }
}    

if (opt=='GS') {
 tempKernelParam<- seq(min(kernelParams[c(1,2)]),max(kernelParams[c(1,2)]),by=(max(kernelParams[c(1,2)])-min(kernelParams[c(1,2)]))/kernelParams[3]) #change the third value on kernelParams if you want a different gridsearch sampling scheme
  if (kernelType=='p'){
    tempKernelParam2<-round(tempKernelParam)
    if (!(sum(!tempKernelParam==tempKernelParam2)==0)){
    print('rounded of your grid search values, please only use integer values with polynomial kernel')
    }
  }  
}

if (!((preProcK=='mc')|(preProcK=='none'))){
 warning('this is an incorrect setting for kernel matrix scaling, preProcK')
}

if (!((preProcY=='uv')|(preProcY=='mc')|(preProcY=='none')|(preProcY=='pareto'))){
 warning('this is an incorrect setting for Y scaling, preProcY')
} 

if( (as.logical((match(modelType,'da',nomatch=0)))+(as.logical((match(modelType,'daAUC',nomatch=0)))))>0){    
	drRule<-'max'; 
	tmp<-unique(as.vector(unlist(Y)));
    
	if(length(tmp)==2){
	  if(all(tmp==0|tmp==1)){
	    if(m==1){
	      Y<-koplsDummy(Y);
	    }
		classVect<-koplsReDummy(Y);
	  }
	}
	else{
	  if(all(Y%%1==0 && m==1)){
	    classVect<-Y;
	    Y<-koplsDummy(Y+1);
	  }
	}
	nclasses<-length(unique(classVect));
 }

if(as.logical(match(cvType,'mccvb',nomatch=0)) && !((as.logical(match(modelType,'da',nomatch=0)))|(as.logical(match(modelType,'daAUC',nomatch=0))))){
    stop('Class balanced monte-carlo cross validation only applicable to da modelling')
  }

if(!any(c(as.logical(match(cvType,'mccvb',nomatch=0))) , as.logical(match(cvType,'mccv',nomatch=0)) , as.logical(match(cvType,'nfold',nomatch=0)))){
    stop(paste(cvType, '- unknown Cross-validation type'));
  }

YcenterType<-"no";
YscaleType<-"no";
if (preProcY!="no") {
    YcenterType<-"mc";
    if (preProcY!="mc") {
        YscaleType<-preProcY;
    }
}
  
oay<-0;
Yhat<-NULL;
YhatDaSave<-array(list(),c(oax+1,oay+1));


pressyVars<-array(list(),c(oax+1,oay+1));
pressyVarsTot<-array(list(),c(oax+1,oay+1));
pressy<-matrix(NaN,oax+1,oay+1);
pressyTot<-matrix(NaN,oax+1,oay+1);
cvTestIndex<-NULL;
cvTrainingIndex<-NULL;

	
	
	
	
for( icv in 1:nrcvouter){
  if (verbose)
  {
  	print(paste('Cross validation round: ',icv,'...'));
  }     
  #set up cv
   if (is.matrix(Y)==FALSE){
    if (is.vector(Y)==TRUE){
      Y<-matrix(Y,ncol=1)
    } else{
      warning('somehow your Y is not a vector nor matrix')
    }
  }

  cvSet<-koplsCrossValSet(K=X,Y=Y,type=cvType,nfold=nrcvouter,i=icv,trainFrac=cvFrac) 
  cvTestIndex<-c(cvTestIndex,cvSet$testInd);
  cvTrainingIndex<-c(cvTrainingIndex,cvSet$trainInd);
  
  ### opt/SA start
  if (opt=='SA') {
    if (!is.null(kernelParams)) {
      stXinput <- kernelParams
    } else {
      stXinput<- NULL
    } 
    settings <- koplsSA(Xtr=as.matrix(X[cvSet$trainInd,,drop=FALSE]),Ytr=as.matrix(Y[cvSet$trainInd,,drop=FALSE]),A=A,oax=oax,modelType=modelType,kernelType=kernelType,nrcvinner=nrcvinner,cvType=cvType,cvFrac=cvFrac,stX=stXinput,preProcK=preProcK,preProcY=preProcY,verbose=verbose,...) 
    modelMain$SA[icv]<- list(settings)
    if (settings$nrreps>1){
      modelMain$kernelParamslist[icv] <- median(unlist(settings$Optset)) 
    } else {
      modelMain$kernelParamslist[icv]<- settings$Optset
    }
  kernelParamsFinal=modelMain$kernelParamslist[[icv]]

  } else {
    if (opt=='GS') {
      tempGSresults<- NULL  
      for (counter in 1:length(tempKernelParam)) {        
              tempGSresults[counter]<-  koplsModelInternal(Xtr=as.matrix(X[cvSet$trainInd,,drop=FALSE]),Ytr=as.matrix(Y[cvSet$trainInd,,drop=FALSE]),A=A,oax=oax,nrcv=nrcvinner,cvType=cvType,preProcK=preProcK,preProcY=preProcY,cvFrac=cvFrac,modelType=modelType,kernelType=kernelType,kParamNew=tempKernelParam[counter])
      }
      modelMain$GS$results[icv]<- list(tempGSresults)
      modelMain$GS$settings[icv]<- list(tempKernelParam) 
      optval<- min(modelMain$GS$results[icv][[1]])
      modelMain$kernelParamslist[icv]<- tempKernelParam[which.min(modelMain$GS$results[icv][[1]])]
      kernelParamsFinal=modelMain$kernelParamslist[icv]
    } else {
      if (opt=='no') {
        modelMain$kernelParamslist[icv]=kernelParams    
        kernelParamsFinal<-kernelParams    
      } else {
        warning('this is not a valid optimisation setting')
      }
    }
  }
  ### end of  opt/SA
  K<- koplsKernel(X1=X,Ktype=kernelType,param=kernelParamsFinal)
    
  # update the cvSet object with new Kernel parts from optimisation
  cvSet$KTrTr=K[cvSet$trainInd,cvSet$trainInd]
  cvSet$KTeTr=K[cvSet$testInd,cvSet$trainInd]
  cvSet$KTeTe=K[cvSet$testInd,cvSet$testInd]
     
  # get Kernel matrices ------- change so that this is done in the K
  # matrix only once and selected by indeces.
  KtrTr<-cvSet$KTrTr
  KteTe<-cvSet$KTeTe
  KteTr<-cvSet$KTeTr

  # center Y and K matrices
  YScaleObj<-koplsScale(x=cvSet$yTraining,center=YcenterType,scale=YscaleType);
  YScaleObjTest<-koplsScaleApply(model=YScaleObj,x=cvSet$yTest);
  if (preProcK=="mc") {
	KteTe<-koplsCenterKTeTe(KteTe=KteTe,KteTr=KteTr,KtrTr=KtrTr);
	KteTr<-koplsCenterKTeTr(KteTr=KteTr,Ktrain=KtrTr);
	KtrTr<-koplsCenterKTrTr(K=KtrTr);
  }
  

  model<-koplsModel(K=KtrTr,Y=YScaleObj$x,A=A,nox=oax,preProcK='none',preProcY='none');
    ssy<-sum((YScaleObjTest$x)^2);
    ssyVars<-colSums((YScaleObjTest$x)^2);	
    ssx<-sum(diag(KteTe));

    if(icv==1){
      ssyTot<-ssy;
      ssyVarsTot<-ssyVars;
      ssxTot<-ssx;
    }    else{
      ssyTot<-ssyTot+ssy;
      ssyVarsTot<-ssyVarsTot+ssyVars;        
      ssxTot<-ssxTot+ssx;
      }
     
  for( ioax in 1:(oax+1)){
    for( ioay in 1:1){#(oay+1)){
      modelPredy<-koplsPredict(KteTr=KteTr, Ktest=KteTe,Ktrain=KtrTr, model=model,nox=ioax-1,rescaleY=FALSE);	   
      pressy[ioax, ioay]<-sum((YScaleObjTest$x-modelPredy$Yhat)^2);
      pressyVars[ioax, ioay]<-list(colSums((YScaleObjTest$x-modelPredy$Yhat)^2));
             if((icv==1)){
                pressyTot[ioax,ioay]<-pressy[ioax,ioay];
                pressyVarsTot[ioax,ioay]<-pressyVars[ioax,ioay];
            }            else{
                pressyTot[ioax,ioay]<-pressyTot[ioax,ioay]+pressy[ioax,ioay];
                pressyVarsTot[ioax,ioay]<-list(pressyVarsTot[ioax,ioay][[1]]+pressyVars[ioax,ioay][[1]]);
              }
        if( (as.logical((match(modelType,'da',nomatch=0)))+(as.logical((match(modelType,'daAUC',nomatch=0)))))>0){    
                    tmp<-koplsRescale(model=YScaleObj,x=modelPredy$Yhat);
                    YhatDaSave[ioax,ioay]<-list(rbind(YhatDaSave[ioax,ioay][[1]],tmp));                               
                  }
            if(ioax==oax+1){               
                    tmp<-koplsRescale(model=YScaleObj,x=modelPredy$Yhat);
                    Yhat<-rbind(Yhat,tmp);
                  }
  }
}
  
}#end icv

# Calculate a final model 
	  if (opt=='no'){       
      KtrTr<-K
      modelMain$koplsModel<-koplsModel(K=as.matrix(KtrTr),Y=as.matrix(Y),A=A,nox=oax,preProcK=preProcK,preProcY=preProcY)
    }         
    if (opt=='SA'){
      if (verbose)
  {
  	print(paste('Final model building'));
  }
      settingsTemp <- koplsSA(Xtr=as.matrix(X),Ytr=as.matrix(Y),A=A,oax=oax,modelType=modelType,kernelType=kernelType,nrcvinner=nrcvinner,cvType=cvType,cvFrac=cvFrac,stX=stXinput,preProcK=preProcK,preProcY=preProcY,...) 
      modelMain$KParamfinal<-settingsTemp$Optset[[1]]
      K<-koplsKernel(X1=as.matrix(X),Ktype=kernelType,param=modelMain$KParamfinal)
      modelMain$koplsModel<-koplsModel(K=as.matrix(K),Y=as.matrix(Y),A=A,nox=oax,preProcK=preProcK,preProcY=preProcY); 
      timeans<-(proc.time()-CVptm)[3]   
      modelMain$time<-timeans
    }                           
    if (opt=='GS'){
           if (verbose){
  	        print(paste('Final model building'));
         }
    ALLtempGSresults<- NULL  
      for (counter in 1:length(tempKernelParam)) {        
        ALLtempGSresults[counter]<-  koplsModelInternal(X=as.matrix(X),Y=as.matrix(Y),A=A,oax=oax,nrcv=nrcvinner,cvType=cvType,preProcK=preProcK,preProcY=preProcY,cvFrac=cvFrac,modelType=modelType,kernelType=kernelType,kParamNew=tempKernelParam[counter])
      }
      modelMain$KParamfinal<- tempKernelParam[which.min(ALLtempGSresults)]
		  K<-koplsKernel(X1=as.matrix(X),Ktype=kernelType,param=modelMain$KParamfinal)
      modelMain$koplsModel<-koplsModel(K=as.matrix(K),Y=as.matrix(Y),A=A,nox=oax,preProcK=preProcK,preProcY=preProcY); 
      timeans<-(proc.time()-CVptm)[3]   
      modelMain$time<-timeans
	  }
    modelMain$cv$Yhat<-Yhat;
    modelMain$cv$Tcv<-Yhat%*%modelMain$koplsModel$Cp%*%modelMain$koplsModel$Bt[[oax+1]];


    modelMain$cv$Q2Yhat<-NULL;
    modelMain$cv$Q2YhatVars<-array(list(),c(oax+1,oay+1));

    for( ioax in 1:(oax+1)){
        for( ioay in 1:(oay+1)){
            modelMain$cv$Q2Yhat[ioax,ioay]<-1-pressyTot[ioax,ioay]/ssyTot;          
            modelMain$cv$Q2YhatVars[ioax,ioay]<-list(1-pressyVarsTot[ioax,ioay][[1]]/ssyVarsTot);

}
}

    modelMain$cv$cvTestIndex<-cvTestIndex;
    modelMain$cv$cvTrainingIndex<-cvTrainingIndex;

if( (as.logical((match(modelType,'da',nomatch=0)))+(as.logical((match(modelType,'daAUC',nomatch=0)))))>0){    


sensSpecRes<-list(1);
da<-list(1);
        #get sens/spec for each y-orth component... eval of model
  for( i in 1:(oax+1)){ 
    if(as.logical(match(drRule,'max',nomatch=0)) ){
      predClass<-koplsMaxClassify(YhatDaSave[i,1][[1]]);
    }
                else{
                  if(as.logical(match(drRule,'fixed',nomatch=0))){
                    predClass<-koplsBasicClassify(data=YhatDaSave[i,1][[1]],k=1/nclasses);
                  }
                  else{
                    stop(paste('Decision rule given: ',drRule,'is not valid/implemented'))
                  }
                }
da$sensSpec[[i]]<-koplsSensSpec(trueClass=classVect[cvTestIndex], predClass=predClass);   
if (((dim(YhatDaSave[[ioax,ioay]])[2]<3))+(length(unique(classVect[cvTestIndex]))==2)==2){
da$ROC[[i]]<-koplsRoc(data=YhatDaSave[[ioax,ioay]],trueclass=classVect[cvTestIndex])	
}
  }
 
           da$confusionMatrix<-koplsConfusionMatrix(true=classVect[cvTestIndex], pred=predClass);
           da$trueClass<-classVect[cvTestIndex];
            da$nclasses<-nclasses;
        modelMain$da<-da;
        modelMain$da$predClass<-predClass;        
        modelMain$da$decisionRule<-drRule;
                #CHANGE TO ORIGINAL ORDER IF NFOLD CV - for backward
                #compatibility and comparison w/ simca-p etc
        if(as.logical(match(cvType,'nfold',nomatch=0))){
            tmp<-sort(cvTestIndex,index.return=TRUE);
            cvOrder<-tmp$ix;
            modelMain$da$predClass<-modelMain$da$predClass[cvOrder];
            modelMain$da$trueClass<-modelMain$da$trueClass[cvOrder];           
        }
}#end if da

    #CHANGE TO ORIGINAL ORDER IF NFOLD CV - for backward
    #compatibility and comparison w/ simca-p etc
    if(as.logical(match(cvType,'nfold',nomatch=0))){
        
        tmp<-sort(cvTestIndex,index.return=TRUE);
        cvOrder<-tmp$ix;
        modelMain$cv$Yhat<-modelMain$cv$Yhat[cvOrder,];

        modelMain$cv$Tcv<-modelMain$cv$Tcv[cvOrder,];

}
  
modelMain$release<-release;
modelMain$args$oax<-oax;
modelMain$args$A<-A;
modelMain$kernelParamsList<-kernelParamtemp
class(modelMain)<-"koplscvopt"

###################################################################################


return(modelMain);

  }






