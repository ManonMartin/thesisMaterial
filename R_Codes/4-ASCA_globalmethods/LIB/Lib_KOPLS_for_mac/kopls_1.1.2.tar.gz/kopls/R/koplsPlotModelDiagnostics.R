###########################################################################
#
# Plots diagnostic parameters for a K-OPLS model.
# (R2X, R2Xcorr, R2Xortho, and optionally Q2Y).
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsPlotModelDiagnostics<-function(model, plot.values=FALSE, ...) {

	if (class(model) != "kopls") {
		stop(paste("Unknown model type: '", class(model), "' (must be of type 'kopls'). Aborting.", sep=""))
	}
	
	
	
	## Define labels
	labels<-paste("tp", 1:model$A, sep=",")
	if (model$nox > 0)
			labels<-c(labels, paste("to", 1:model$nox, sep=","))	
	
	## Plot
	layout.mat<-matrix(nrow=2, ncol=2, data=1:4, byrow=TRUE)
	layout(layout.mat)
	b<-barplot(model$R2X, names.arg=labels, ylab="R2X (cumulative)", col="Green", xpd=FALSE)
	if (plot.values) {
		for (i in 1:length(b)) {
			par(new=TRUE)
			text(x=b[i],y=(model$R2X[i]-0.05*sign(model$R2X[i])*max(model$R2X)),labels=paste( round(100*model$R2X[i],2), "%", sep=""), ...)
		}
	}
	
	b<-barplot(model$R2XO[2:length(model$R2XO)], names.arg=labels[2:length(model$R2XO)], ylab="R2Xortho (cumulative)", col="Blue")
	if (plot.values) {
		for (i in 1:length(b)) {
			par(new=TRUE)
			text(x=b[i],y=(model$R2XO[i+1]-0.05*sign(model$R2XO[i+1])*max(model$R2XO)),labels=paste( round(100*model$R2XO[i+1],2), "%", sep=""), col="White", ...)
		}
	}

	b<-barplot(model$R2XC, names.arg=labels, ylab="R2Xcorr", col="Red")
	if (plot.values) {
		for (i in 1:length(b)) {
			par(new=TRUE)
			text(x=b[i],y=(model$R2XC[i]-0.05*sign(model$R2XC[i])*max(model$R2XC)),labels=paste( round(100*model$R2XC[i],2), "%", sep=""), col="White", ...)
		}
	}

	if (!is.null(model$Q2))	{
		#browser()
		q2<-as.numeric(model$Q2)
		b<-barplot(q2, names.arg=labels, ylab="Q2Y", col="Yellow")
		if (plot.values) {
			for (i in 1:length(b)) {
				par(new=TRUE)
				text(x=b[i],y=(q2[i]-0.05*sign(q2[i])*max(q2)),labels=paste( round(100*q2[i],2), "%", sep=""), ...)
			}
		}
		
	} else {
		plot.new()
		plot.window(c(0,1),c(0,1))
		text(0.5, 0.5, "Q2Y undefined (cross-validation not performed)", ...)
	}
	layout(1)

}


