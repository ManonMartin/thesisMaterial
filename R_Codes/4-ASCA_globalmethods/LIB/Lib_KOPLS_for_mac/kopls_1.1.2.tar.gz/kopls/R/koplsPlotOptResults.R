###########################################################################
#
# Function for plotting the results of the nested cross-validation for
# optimisation of the kerenel parameter. Plotted are the response value
# (1-Q^2) for 're', 1- mean sensitivity for 'da' or 1-area under ROC curve
# for 'daAUC' optimisation, together with the R values as a function of 
# the number of orthogonal components for the final model after optimisation.
# In the second plot, the kernel parameter optimisation is shown for the
# different CV rounds. Note that only temporary best values are plotted,
# not the whole of the searched space for simulated annealing. For simulated 
# annealing, a bar plot is created demonstrating the time the individual CV 
# rounds took.
#
# ** INPUT
# model = the returned cross-validated model (gridsearch or simulated
#   annealing).
# modelType = 're' for regression, 'da' for discriminant analysis optimised
#   to (mean sensitivity), 'daAUC' for optimised area under receiver
#   operating characteristic curve.
# optmethod = 'SA' (default) or 'GS', method used for optimisation.
#
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsPlotOptResults<-function(model,modelType,optmethod='SA'){ 
	nroc<-length(model$cv$Q2Yhat)-1;
	dev.new();
	par(mfrow=c(2,2));
	plot(0:nroc,model$cv$Q2Yhat,col='blue',type='o',ylim=c(0,1),xlab="# orthogonal components",ylab="Q^2", main="(outer) cross-validation: Q^2");#model$finalmodel$cv$Q2Yhat
	plot(0:nroc,model$koplsModel$R2X,col='red',type='o',ylim=c(0,1),xlab="# orthogonal components",ylab="R2X", main="final model parameters: R2X");
	plot(0:nroc,model$koplsModel$R2XC,col='magenta',type='o',ylim=c(0,1),xlab="# orthogonal components",ylab="R2XC", main="final model parameters: R2XC");
	plot(0:nroc,model$koplsModel$R2XO,col='green',type='o',ylim=c(0,1),xlab="# orthogonal components",ylab="R2XO", main="final model parameters: R2XO");

  minlist<-NULL
  maxlist<-NULL
  if (optmethod=='SA') {
      for (aap in 1:length(model$SA)){
      minlist[aap]<-min(unlist(model$SA[[aap]]$xoptlist))
      maxlist[aap]<-max(unlist(model$SA[[aap]]$xoptlist))
      }
    dev.new()

    timetemp<-NULL
    par(mfrow=c(1,1))
    count1<-length(model$SA)
    if (modelType=='re'){
      plot(c(model$KParamfinal,model$KParamfinal),c(0,1),type='l',col='black',xlab='Kernel Parameter',ylab='1-Q^2',main='Optimisation results for individual CV rounds for simulated annealing',xlim=c(min(unlist(minlist)),max(unlist(maxlist))))
    }
    if (modelType=='da'){
      plot(c(model$KParamfinal,model$KParamfinal),c(0,1),type='l',col='black',xlab='Kernel Parameter',ylab='1-(mean sensitivity)',main='Optimisation results for individual CV rounds for simulated annealing',xlim=c(min(unlist(minlist)),max(unlist(maxlist))))
    }
    if (modelType=='daAUC'){
      plot(c(model$KParamfinal,model$KParamfinal),c(0,1),type='l',col='black',xlab='Kernel Parameter',ylab='1-AUROC',main='Optimisation results for individual CV rounds for simulated annealing',xlim=c(min(unlist(minlist)),max(unlist(maxlist))))
    }  
    for (teli1 in 1:count1){
	points(model$SA[[teli1]]$xoptlist[[1]],model$SA[[teli1]]$foptlist[[1]],type='o',col='blue')
	points(model$SA[[teli1]]$xoptlist[[1]][length(model$SA[[teli1]]$xoptlist[[1]])],model$SA[[teli1]]$foptlist[[1]][length(model$SA[[teli1]]$foptlist[[1]])],type='p',col='red',pch=19,cex=2)
      text(model$SA[[teli1]]$xoptlist[[1]][length(model$SA[[teli1]]$xoptlist[[1]])],model$SA[[teli1]]$foptlist[[1]][length(model$SA[[teli1]]$foptlist[[1]])],paste(teli1))
      timetemp[teli1]=model$SA[[teli1]]$time[[1]]
    }
    text(model$KParamfinal,0.9, paste(round(model$KParamfinal,2)),adj = c(0, 0.5))
    dev.new()
    barplot(timetemp,col='blue',xlab='CV round',ylab='time (s)',main='time per CV',names.arg=seq(1,count1,by=1) )
  }


  if (optmethod=='GS') {
  dev.new()
  par(mfrow=c(1,1))
    count1<-length(model$GS$settings)
    if (modelType=='re'){
      plot(c(model$KParamfinal,model$KParamfinal),c(0,1),type='l',col='black',xlab='Kernel Parameter',ylab='1-Q^2',main='Optimisation results for individual CV rounds for gridsearch',xlim=c(min(model$GS$settings[[1]]),max(model$GS$settings[[1]])))
    }
    if (modelType=='da'){
      plot(c(model$KParamfinal,model$KParamfinal),c(0,1),type='l',col='black',xlab='Kernel Parameter',ylab='1-(mean sensitivity)',main='Optimisation results for individual CV rounds for gridsearch',xlim=c(min(model$GS$settings[[1]]),max(model$GS$settings[[1]])))
    }
    if (modelType=='daAUC'){
      plot(c(model$KParamfinal,model$KParamfinal),c(0,1),type='l',col='black',xlab='Kernel Parameter',ylab='1-AUROC',main='Optimisation results for individual CV rounds for gridsearch',xlim=c(min(model$GS$settings[[1]]),max(model$GS$settings[[1]])))
    }                
    for (teli1 in 1:count1){
	points(model$GS$settings[[teli1]],model$GS$results[[teli1]],type='o',col='blue')
      tempmin<-which.min(model$GS$results[[teli1]])
      points(model$GS$settings[[teli1]][tempmin],model$GS$results[[teli1]][tempmin],type='p',col='red',pch=19,cex=2)
      text(model$GS$settings[[teli1]][tempmin],model$GS$results[[teli1]][tempmin],paste(teli1))
    }
    text(model$KParamfinal,0.9, paste(round(model$KParamfinal,2)),adj = c(0, 0.5))
  }
}

