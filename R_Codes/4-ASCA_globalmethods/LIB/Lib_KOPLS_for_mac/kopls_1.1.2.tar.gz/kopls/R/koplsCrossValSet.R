###########################################################################
#
# Fetches a set of training/test observations for cross-validation.
# K = Kernel matrix
# Y = response matrix
# type = type of cross-validation:
# 	'nfold' for n-fold, 'mccv' for monte-carlo, 'mccvb' for 
#   	monte-carlo class-balanced
# nfold =  number of total nfold rounds (if type='nfold')
# i =  Current nfold rounds (if type='nfold')
# trainFrac = fraction of observations in training set.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

"koplsCrossValSet" <-
function(K,Y,type='nfold',nfold,i,trainFrac=(2/3)){
	#nobs is the total number of observations
	#Y is the response matrix vector
	#type is type of Cross validation; nfold,mc or mccb
	#i is the order, if nfold...set i to N for Leave one out Cross validation
	#trainFrac is the fraction of the data that is used for training set if mc or mccb
	   
	
	if(type=='nfold'){ # make srue that at least one of X and K are not NA.
		testInd<-seq(i,nrow(K),nfold);
		trainInd<-setdiff(1:nrow(K),testInd);
	}

	if(type=='mccv'){
		randomSeq<-rnorm(nrow(K));
		ind<-sort(randomSeq,index.return = TRUE)$ix;
		trainSize<-floor(nrow(K)*trainFrac);
		trainInd<-ind[1:trainSize];
		testInd<-ind[(trainSize+1):nrow(K)];
	}

	if(type=='mccvb'){
		#assume that we have a dummy matrix as input
		trainInd<-NULL;
		testInd<-NULL;

		class<-koplsReDummy(Y);
		uniqueClass<-unique(class);
		for(i in 1:length(uniqueClass)){
		      ind<-which(class==uniqueClass[i]);
		      ind<-ind[sort(rnorm(length(ind)),index.return=TRUE)$ix];
		      trainSize<-floor(length(ind)*trainFrac);
		      trainInd<-c(trainInd,ind[1:trainSize]);
		      testInd<-c(testInd,ind[(trainSize+1):length(ind)]);
		}#end for each class
	
		
	}#end 'mccb'
	
	if(ncol(K)==nrow(K)){ # THIS IS FOR K
		## Construct Kernel/Y matrices for training/test
		KTrTr<-K[trainInd,trainInd,drop=FALSE];
		KTeTr<-K[testInd,trainInd,drop=FALSE];
		KTeTe<-K[testInd,testInd,drop=FALSE];
		yTrain<-Y[trainInd,,drop=FALSE];
		yTest<-Y[testInd,,drop=FALSE];
	}else{ # if using X matrix as input, only provide indeces...
		#warning('Argument K is not square, will only return trainInd and testInd (this is ok if you are running SA optimization)');
		KTrTr<-NA;
		KTeTr<-NA;
		KTeTe<-NA;
		yTrain<-Y[trainInd,,drop=FALSE];		
		yTest<-Y[testInd,,drop=FALSE];
	}

	
		
	
	return(list(KTrTr=KTrTr, KTeTr=KTeTr, KTeTe=KTeTe, yTraining=yTrain, yTest=yTest, trainInd=trainInd, testInd=testInd, class='crossValSet'));
}

