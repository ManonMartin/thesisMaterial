###########################################################################
#
# Create a kopls model using cross-validation
# Input parameters:
# Xtr       = Training X data.
# Ytr       = Training Y data.
# A         = The number of Y-predictive components (integer).
# oax       = The number of Y-orthogonal components (integer).
# nrcv      = Number of cross-validation rounds (integer).
# cvType    = Type of cross-validation. Either 'nfold' for n-fold
#             cross-validation, 'mccv' for Monte Carlo CV or 'mccvb' for
#             Monte Carlo class-balanced CV. See also 'koplsCrossValSet()'.
# preProcK  = Scaling of kernel; e.g. 'mc' for meancentering and 'none' for no 
#             scaling.
# preProcY  = Scaling of Y data; e.g. 'mc' for meancentering and 'uv' for mc + 
#             scaling to unit variance, 'pareto' for mc + Pareto-scaling or, 
#             'none' for no scaling.
# cvFrac    = Fraction of observations in the trainingset during
#             crossvalidation. Only applicable to 'mccv', 'mccvb'
#             crossvalidation (see 'cvType').
# modelType = 'da' for discriminant analysis, 're' for regression.
#             If 'da', the mean sensitivity is optimised, for 'daAUC' the area
#             under the receiver operating characteristic curve is optimised 
#             (only for two-class problems). 
# kernelType= Kernel type, e.g. 'g' for Gaussian or 'p' for polynomial. When 
#             using 'p' make sure the kernel parameter is not too big to
#             prevent the polynomial from exploding, resulting in SVD errors.
# kParamNew	= New kernel parameter to test.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsModelInternal<-function(Xtr,Ytr,A,oax,nrcv,cvType,preProcK,preProcY,cvFrac,modelType,kernelType,kParamNew) {
  modelCV<-koplsCVopt(X=Xtr,Y=Ytr,A=A,oax=oax,modelType=modelType,opt='no',nrcvouter=nrcv,cvType=cvType,preProcK=preProcK,preProcY=preProcY,cvFrac=cvFrac,verbose=FALSE,kernelType=kernelType,kernelParams=kParamNew) 
  if (modelType=='re'){
    return(1-as.numeric(modelCV$cv$Q2Yhat[length(modelCV$cv$Q2Yhat)])) 
  } else {
    if (modelType=='da') {
      return(1-as.numeric(modelCV$da$sensSpec[[length(modelCV$da$sensSpec)]]$totalResults$meanSens)) 
    } else {
      if (modelType=='daAUC') {
        return(1-as.numeric(modelCV$da$ROC[[length(modelCV$da$ROC)]]$AUC)) 
      } else { 
        warning('this is an incorrect modeltype setting')
      }
    }
  }
}
