###########################################################################
# Plots sensitivity and specificity values from K-OPLS cross-validation.
# v = row vector of true class assignments (template)
# m = matrix (or row vector) of class assignments to be compared.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsPlotSensSpec<-function(modelFull) {

	
	
	# Plots sensitivity (true positive rate) and specificity (true negative rate)
	# v = row vector of true class assignments (template)
	# m = matrix (or row vector) of class assignments to be compared.
	#
	# Max Bylesj�
	# Research Group for Chemometrics
	# Department of Organic Chemistry
	# Ume� University
	# Sweden

	if (class(modelFull) != 'koplscv')
	    stop("Unknown model type (must be of type 'koplscv'). Aborting.");
	end

	if (is.null(modelFull$da)) {
		stop("The cross-validation results are not for discriminant analysis. Aborting");
	}
	
	
	#res<-koplsSensSpec(modelFull$da$trueClass, modelFull$da$predClass);


	
	plot.mat<-matrix(ncol=2, nrow=length(modelFull$da$sensSpec), data=0)
	colnames(plot.mat)<-c("Sens", "Spec")
	rownames(plot.mat)<-paste("to", 0:modelFull$args$oax, sep=",")
	for (i in 1:nrow(plot.mat))
	{
		plot.mat[i, "Sens"]<-modelFull$da$sensSpec[[i]]$totalResults$sensTot;
		plot.mat[i, "Spec"]<-modelFull$da$sensSpec[[i]]$totalResults$specTot;
	}
	#browser()
	
	## Construct a matrix for plotting
	#num.classes<-length(res$classResults)
	#sens.vec<-rep(0, num.classes)
	#spec.vec<-rep(0, num.classes)
	#tot.vec<-rep(0, max(num.classes,2))
	#for (i in 1:num.classes) {
	#	sens.vec[i]<-res$classResults[[i]]$sens
	#	spec.vec[i]<-res$classResults[[i]]$spec
	#}
	#tot.vec[1]<-res$totalResults$sensTot
	#tot.vec[2]<-res$totalResults$specTot
	
	#plot.mat<-cbind(sens.vec, spec.vec, tot.vec)
	#rownames(plot.mat)<-paste("Class", 1:nrow(plot.mat), sep="")
	
	b<-barplot(t(plot.mat), beside=TRUE, legend=c("Sens.", "Spec."), ylab="Sens. and spec.(%)" );

	modelFull$da$sensSpec

}
