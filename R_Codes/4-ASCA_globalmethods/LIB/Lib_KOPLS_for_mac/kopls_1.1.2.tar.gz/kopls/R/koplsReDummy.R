###########################################################################
#
# Reconstructs a (integer) class vector from a binary (dummy) matrix.
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

"koplsReDummy" <-
function(dummy){
	
	#revert the dummy to original vector of class labels
	class<-matrix(NA,ncol=1,nrow=nrow(dummy));
	for(i in 1:ncol(dummy)){
		#if(any(!is.na(as.numeric(colnames(dummy))))){
		if (all(is.numeric(colnames(dummy)))) {
			class[dummy[,i]>0,1]<-as.numeric(colnames(dummy))[i];
		}
		else{
		  if (is.null(colnames(dummy))){
		  colnames(dummy)<-1:dim(dummy)[2]#JMF fix if no colheaders
		  }
			#class[dummy[,i]>0,1]<-i;#assign class numbers(int)
			class[dummy[,i]>0,1]<-(colnames(dummy))[i];#assign class as strings based on labels in original class vector
		}
	}
return(class);
}
