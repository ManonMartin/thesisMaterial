###########################################################################
#
# Calculates a confusion matrix from two vectors:
# true = True class belonging
# pred = Predicted class belonging
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################

koplsConfusionMatrix<-function(true,pred){
if (!is.numeric(unique(true))){
          a1<-koplsDummy(true)
         	true2<-matrix(NA,ncol=1,nrow=nrow(a1))
          for(i in 1:ncol(a1)){
       		  colnames(a1)<-1:dim(a1)[2]
		  			true2[a1[,i]>0,1]<-(colnames(a1))[i]
		  			}          
     true<-true2
}
uniqueClass=unique(true);
nclasses<-length(uniqueClass);
A<-matrix(rep(0,nclasses^2),ncol=nclasses);
for(i in 1:nclasses){
  indTrue=which(true==uniqueClass[i]);
  for(j in 1:length(indTrue)){
    #pred(indTrue(j))
    #[find(uniqueClass==pred(indTrue(j)))\
    A[i,which(uniqueClass==pred[indTrue[j]])]<-A[i,which(uniqueClass==pred[indTrue[j]])]+1;
  }
  A[i,]=A[i,]/length(indTrue);
}
return(A);
}
